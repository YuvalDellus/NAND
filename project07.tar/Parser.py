import re


# # recives a file
# # trim
# # reads and treats line by line
#
#
# def Constructor():
#     pass
# def hasMoreLines():
#     pass
# def advance():
#     pass
#
# def command_type():
#     '''
#     decides what type is the command
#     :return: matching constant:
#     C_ARITMETIC, C_PUSH, C_POP, C_LABEL,C_return
#     '''
#
# def arg1():
#     pass
# def arg2():
#     pass'


# def ignore_white_space(line):
#     new_line=" "
#     for i,symbol in enumerate(line):
#         if i==0 and symbol!=" ":


def read_single_line(line):
    # p = re.compile("^\s*\/\/")  # check if comment
    # m = p.match(line)
    # if m: return
    p = re.compile(
        "^\s*([a-z]+)\s*([a-z]*)\s*(\-*[0-9]*)")  # select the acctual text from the line
    m = p.match(line)
    if m:
        return m.group(0), m.group(1), m.group(2), m.group(3)
    return (None, None, None, None)



read_single_line("  push as 4")
