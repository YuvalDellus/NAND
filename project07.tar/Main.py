import glob, os, sys
import Parser
import CodeWriter



def receive_input():
    '''
    checks if directory is a single file or a directory to multiple files
    :return:an array of files to work on
    '''
    if os.path.isdir(sys.argv[1]):
        files = []
        for filename in glob.glob(os.path.join(sys.argv[1], "*.vm")):
            files.append(open(filename, "r"))
        return files
    else:
        return [open(sys.argv[1], "r")]



def main():

    files_list = receive_input()

    for file in files_list:
        line = file.readline()
        output = ""
        line_num=0
        path=os.path.basename(file.name)

        file_name = os.path.splitext(path)[0]

        while line:


            command_txt, command_type, memory_address, argument = Parser.read_single_line(
                line)
            asm_lines = CodeWriter.translator(command_type, memory_address,
                                              argument, file_name,line_num)
            if (command_txt):
                output+="//" + command_txt+"\n"
                line_num += 1
            if(asm_lines):
                output += asm_lines
            line = file.readline()


        asm_code = open(file.name.replace(".vm", ".asm"), "w")
        asm_code.write(output)
        file.close()
        asm_code.close()


main()
