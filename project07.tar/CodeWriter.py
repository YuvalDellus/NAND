PUSH = "@SP\nA=M\nM=D\n@SP\nM=M+1\n"  # entering the number for position and updates SP
PUSH_PREFIX1 = "@%s\nD=A\n@%s\nA=M+D\nD=M\n"  # for regular numbers
PUSH_PREFIX2 = "@%s\nD=A\n"  # for static
PUSH_PREFIX3 = "@%s\nD=M\n"  # for pointers
PUSH_PREFIX4 = "@%s\nD=A\nD=D-1\nD=!D\n"  # for negative numbers (only in const)

POP = "@%s\nD=A\n@%s\nD=M+D\n@14\nM=D\n@13\nD=M\n@14\nA=M\nM=D\n"
POP_PREFIX = "@SP\nM=M-1\n@SP\nA=M\nD=M\n@13\nM=D\n"
POP_POINTER = "@%s\nM=D\n"

OVER_FLOW_HANDLE = "@SP\nA=M-1\nA=A-1\nD=!M\nA=A+1\nD=D&M\n@NOOVERFLOW%d\nD;JGE\n@SP\nM=M-1\nA=M-1\n" \
                   "M=%d\n@FIN%d\nD;JMP\n(NOOVERFLOW%d)\n"
SET_ANSWER_TO_TRUE = "D=M\n@SP\nA=M-1\nD=M-D\nM=-1\n"
FINAL_COMPARISON = "@SKIP%d\nD;%s\n@SP\nA=M-1\nD=D-M\nM=0\n(SKIP%d)\n(FIN%d)\n"
GET_TOP = "@SP\nM=M-1\nA=M\n"

valid_names = {"local": "LCL", "argument": "ARG", "this": "THIS",
               "that": "THAT", "temp": "5", "static": "16"}


def push_command(address, arg, file_name=None):
    '''
    :param address: type of the needed segment in the memory (local, pointers, etc..)
    :param arg: number in the segment
    :param file_name:
    :return: code for executing the push command from the requested segment in
     the memory
    '''
    if address in valid_names.keys():
        return PUSH_PREFIX1 % (arg, valid_names.get(address)) + PUSH

    if address == "constant":
        if "-" in arg:
            arg = arg.replace("-", "")
            address = arg
            return PUSH_PREFIX4 % address + PUSH
        address = arg

    if address == "static":
        address = "%s.%s" % (file_name, arg)

    if address == "pointer":
        if arg == "0":
            address = "THIS"
            return PUSH_PREFIX3 % address + PUSH
        else:
            address = "THAT"
            return PUSH_PREFIX3 % address + PUSH

    return PUSH_PREFIX2 % address + PUSH


def pop_command(address, arg):
    '''
    :param address: type of the needed segment in the memory (local, pointers, etc..)
    :param arg: number in the segment
    :return:assembly code for executing the pop command to the requested segment in
     the memory
    '''
    if address in valid_names.keys():
        return POP_PREFIX + POP % (arg, valid_names.get(address))
    if address == "pointer":
        if arg == "0":
            address = "THIS"
        else:
            address = "THAT"
        return POP_PREFIX + POP_POINTER % address


def add_command(sign="+"):
    '''
    :param sign: whether to add or subtract
    :return:assembly code for executing the addition command of last two
    components of the stack
    '''
    return GET_TOP + "D=M\n@SP\nA=M-1\nM=M%sD\n" % (sign)


def sub_command():
    '''
    :return:code for executing the subtraction command of last two components
    of the stack
    '''
    return add_command("-")


def neg_command():
    '''
    :return: code for executing the negation command of last component
    in the stack
    '''
    return "@0\nD=A\n@SP\nA=M-1\nM=D-M\n"


def compare_command(c_type, line_num):
    '''
    :param c_type: requested comparision
    :param line_num: number of command
    :return: code for executing the commemoration(gt,lt,eq) command of
    last two components of the stack
    '''
    if (c_type == "gt"):
        result = 0
    else:
        result = -1
    out = OVER_FLOW_HANDLE % (line_num, result, line_num, line_num)
    out += GET_TOP + SET_ANSWER_TO_TRUE + FINAL_COMPARISON % (
        line_num, c_type, line_num, line_num)
    return out


def not_command():
    '''
    :return:code for executing the bit-wise negation command of last component
     in the stack
    '''
    return "@SP\nA=M-1\nM=!M\n"


def or_and_commands(operator):
    '''
    :param operator:
    :return:code for executing the bit-wise and/or command of last component
     in the stack
    '''
    return GET_TOP + "D=M\n@SP\nA=M-1\nM=D%sM\n" % operator


def translator(command_type, adress, argument, file_name, line_num):
    '''
    :param command_type:
    :param adress:
    :param argument:
    :param file_name:
    :param line_num:
    :return: recives parameters of command line and sends it to the suitable
    function
    '''
    if (command_type == "push"):
        return push_command(adress, argument, file_name)
    if (command_type == "pop"):
        return pop_command(adress, argument)
    if (command_type == "add"):
        return add_command()
    if (command_type == "sub"):
        return sub_command()
    if (command_type == "neg"):
        return neg_command()
    if (command_type == "eq"):
        return compare_command("JEQ", line_num)
    if (command_type == "gt"):
        return compare_command("JGT", line_num)
    if (command_type == "lt"):
        return compare_command("JLT", line_num)
    if (command_type == "not"):
        return not_command()
    if (command_type == "or"):
        return or_and_commands("|")
    if (command_type == "and"):
        return or_and_commands("&")
    return None
