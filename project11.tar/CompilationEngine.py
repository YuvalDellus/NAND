import re
import SymbolTable, VMWriter

possible_operators = {
    "+": "+", "-": "-", "*": "*",
    "/": "/", "&amp;": "&", "|": "|",
    "&lt;": "<", "&gt;": ">", "=": "=", "~": "~"
}


class CompilationEngine:
    """"
    This class responsible to take an Xml file full of tokens and translate it to different indentation levels in the code
    """

    def __init__(self, input, output_file):

        self._tokens = input.split("\n")

        self.vm = VMWriter.VMWriter(output_file)
        self._tokens_index = 1
        self.curr_token = self._tokens[self._tokens_index]
        self.method_table = SymbolTable.SymbolTable()
        self.compileClass()

    def advance(self):
        """
        advance the curr token to the next token
        :return: current token after advance
        """
        if (self.curr_token):
            self._tokens_index += 1
            self.curr_token = self._tokens[self._tokens_index]

    def compileClass(self):
        """
        The first function of the program, start the translation in the class level
        """
        self.advance()
        self.curr_class_name = self.get_token_name()
        for i in range(2): self.advance()
        self.compile_class_var_dec()
        self.compile_subroutine()

        # self.eat(["}"], self.curr_token)

    def compile_general_var_dec(self, key_list, symbol_table):
        """
        responsible to translate different types of variables in the class declaretion
        :param key_list: different types of variables
        :param tag_name: The type of the variable
        """
        while self.curr_token and self.get_token_name() in key_list:

            kind = self.get_token_name()
            self.advance()
            type = self.get_token_name()
            self.advance()

            while "," in self.get_next_token() or ";" in self.get_next_token():
                name = self.get_token_name()
                symbol_table.define(name, type, kind)
                self.advance()
                self.advance()
                if self.get_token_name() == "return": break

    def compile_class_var_dec(self):
        """
        translate different types of variables in the class declaretion
        """
        self.class_table = SymbolTable.SymbolTable()
        self.compile_general_var_dec(["static", "field"], self.class_table)

    def compile_subroutine(self):
        """
        translate subroutines in the class
        """
        while self.get_token_name() not in ["function", "method", "constructor"]:
            self.advance()

        while self.get_token_name() in ["function", "method", "constructor"]:
            self.object_function_flag = False
            self.method_table.start_subroutine()
            self.origin = self.get_token_name()

            if (self.get_token_name() == "method"):
                self.method_table.define("this", self.curr_class_name, "argument")

            self.advance()
            self.void_flag = self.get_token_name() == "void"
            self.advance()
            method_name = self.get_token_name()
            self.advance()
            self.advance()

            while (self.get_token_name() != ")"):
                if ("," in self.get_token_name()):
                    self.advance()
                type = self.get_token_name()
                self.advance()
                name = self.get_token_name()
                self.advance()
                self.method_table.define(name, type, "argument")

            self.enter_sentence("{")

            self.subroutine_body(method_name)

    def subroutine_body(self, method_name):
        """
        translate subroutines body
        """

        full_method_name = self.curr_class_name + "." + method_name
        self.compile_general_var_dec(["var"], self.method_table)
        method_arg_num = self.method_table.get_size() - self.method_table.varCount("argument")

        self.vm.write_function(full_method_name, method_arg_num)

        if self.origin == "method":
            self.vm.write_push("argument", 0)
            self.vm.write_pop("pointer", 0)

        if self.origin == "constructor": self.vm.write_alloc(self.class_table.varCount("field"))

        self.statments()

        self.enter_sentence("}")

    def get_token_name(self):
        """
        finds and diffine diffrent parts in a line
        :param line: the given line
        :return: the match part
        """
        p = re.compile("(<(.*)>) (.*) ")
        m = p.match(self.curr_token)
        if (m):
            return m.group(3)

    def get_token_type(self):
        """
        finds and diffine diffrent parts in a line
        :param line: the given line
        :return: the match part
        """
        p = re.compile("(<(.*)>) (.*) ")
        m = p.match(self.curr_token)
        if (m):
            return m.group(2)

    def enter_sentence(self, end_symb, enter_last=True):
        """
        enter whole sentences till it run into a given symbol
        :param end_symb: the symbol wich signals to stop entering more tokens
        :param enter_last: enter the last token iff True
        """
        token = self.get_token_name()
        while (token != end_symb and token):
            self.advance()
            token = self.get_token_name()

        if (enter_last):
            self.advance()

    def statments(self):
        """
         translate statments in the class
        :return:
        """
        statment_dict = {
            "<keyword> let </keyword>": self.compile_let,
            "<keyword> if </keyword>": self.compile_if,
            "<keyword> do </keyword>": self.compile_do,
            "<keyword> while </keyword>": self.compile_while,
            "<keyword> return </keyword>": self.compile_return
        }

        while self.curr_token in statment_dict:
            statment_dict[self.curr_token]()  # calling the right function depends of what type of statement its have

    def compile_let(self):
        """
        translate the let statement
        """
        self.advance()  # let declaration
        name = self.get_token_name()
        table = self.get_var_table(name)
        kind = table.kind_of(name)
        index = table.index_of(name)
        self.advance()

        if self.get_token_name() != "[":
            self.advance()  # =
            self.compile_expression()

            self.vm.write_pop(kind, index)
            self.enter_sentence(";")

        else:
            self.vm.write_push(kind, index)
            self.advance()
            self.compile_expression()  # i
            self.vm.write_arithmetic("+")
            self.enter_sentence("=")  # ]=
            self.compile_expression()
            self.vm.write_pop("temp", 0)
            self.vm.write_pop("pointer", 1)
            self.vm.write_push("temp", 0)
            self.vm.write_pop("that", 0)
            self.advance()  # ;

    def compile_if(self):
        """
        translate the if statement
        """
        self.enter_sentence("(")
        self.compile_expression()
        self.vm.write_arithmetic("~unary")
        label_1 = "IF_LABEL_1_%d" % self._tokens_index
        label_2 = "IF_LABEL_2_%d" % self._tokens_index
        self.vm.write_if(label_1)
        self.advance()  # )
        self.advance()  # {
        self.statments()
        self.enter_sentence("}")
        self.vm.write_goto(label_2)
        self.vm.write_label(label_1)

        if (self.get_token_name() == "else"):
            self.advance()  # else
            self.advance()  # {
            self.statments()
            self.advance()  # }

        self.vm.write_label(label_2)

    def compile_do(self, is_do=True):
        """
        translate the do statement
        """
        function_name = ""

        if is_do: self.advance()  # do
        while (self.get_token_name() != "("):

            if not function_name:
                object_name = self.get_token_name()

            function_name += self.get_token_name()
            self.advance()

        self.advance()

        arguments_amount = 0

        if (self.origin == "method" or self.origin == "constructor") and "." not in function_name:
            self.vm.write_push("pointer", 0)
            function_name = self.curr_class_name + "." + object_name
            arguments_amount = 1

        # check if what is called is a method

        else:
            table = self.get_var_table(object_name)

            if table:
                kind = table.kind_of(object_name)
                type = table.type_of(object_name)
                index = table.index_of(object_name)

                self.vm.write_push(kind, index)

                arguments_amount = 1

                function_name = function_name.replace(object_name, type, 1)

        arguments_amount += self.compile_exspression_list()
        self.vm.write_call(function_name, arguments_amount)

        if is_do:
            self.vm.write_pop("temp", 0)
            self.enter_sentence(";")

    def compile_while(self):
        """
        translate the while statement
        """
        label_1 = "LABEL_1_%d" % self._tokens_index
        label_2 = "LABEL_2_%d" % self._tokens_index

        self.vm.write_label(label_1)
        self.enter_sentence("(")
        self.compile_expression()
        self.enter_sentence("{")
        self.vm.write_arithmetic("~unary")
        self.vm.write_if(label_2)
        self.statments()
        self.vm.write_goto(label_1)
        self.vm.write_label(label_2)
        self.advance()

    def compile_return(self, fake=False):
        """
        translate the return statement
        """
        if (self.void_flag):
            segment = "constant"
            # if not self.object_function_flag: segment = "pointer"
            self.vm.write_push(segment, 0)

        self.advance()

        if self.get_token_name() != ";":
            self.compile_expression()
            self.advance()  # ;

        self.vm.write_return()

    def compile_expression(self):
        """
        translate the expression
        """

        op_suffix = self.compile_term()

        while (self.get_token_name() in possible_operators):  # check if there are several terms
            op = possible_operators[self.get_token_name()] + op_suffix
            self.advance()
            op_suffix = self.compile_term()

            if op_suffix:  # need this when there are 2 operatros in a row: 3*-2
                self.compile_expression()

            self.vm.write_arithmetic(op)

    def compile_term(self):
        """
        translate the term
        """

        type = self.get_token_type()
        name = self.get_token_name()
        kind = self.get_var_table(name).kind_of(name) if self.get_var_table(name) else None

        if name == "this":
            self.vm.write_push("pointer", 0)
            return ""

        elif (type == "integerConstant"):
            self.vm.write_push("constant", name)
            self.advance()
            return ""

        elif (type == "stringConstant"):
            self.vm.write_string(name)
            self.advance()
            return ""

        elif kind and "." not in self.get_next_token():  # if is a var
            self.vm.write_push(kind, self.get_var_table(name).index_of(name))
            self.advance()
            name = self.get_token_name()
            if (name == "["):
                self.advance()
                self.compile_expression()
                self.vm.write_arithmetic("+")
                self.vm.write_pop("pointer", 1)
                self.vm.write_push("that", 0)
                self.advance()
            return ""

        elif (type == "keyword"):
            self.vm.write_keyword(name)
            self.advance()
            return ""

        elif (name == "("):
            self.advance()

            self.compile_expression()
            self.advance()
            return ""

        elif type == "identifier":
            self.compile_do(False)
            self.advance()
            return ""

        return "unary"

    def compile_exspression_list(self):
        """
        translate several exspression one after the other
        """
        arguments_counter = 0

        if self.get_token_name() != ")":
            arguments_counter += 1
            self.compile_expression()

            while (self.get_token_name() == ","):
                self.advance()
                arguments_counter += 1
                self.compile_expression()
        return arguments_counter

    def get_var_table(self, name):
        """
        return the relevant table, of the class or of the method
        :param name: the name of the var which we looking for
        """
        if self.class_table.is_in(name):
            return self.class_table

        elif self.method_table.is_in(name):
            return self.method_table

        return None

    def get_next_token(self):
        """
        :return: the next token
        """
        return self._tokens[self._tokens_index + 1]
