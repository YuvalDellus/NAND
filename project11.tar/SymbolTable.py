class SymbolTable:
    def __init__(self):
        self.__symbol_table_dict = {}
        self.__counters_dict = {"static": 0, "field": 0, "argument": 0, "local": 0}

    def start_subroutine(self):
        """
        start to zero the symbol table
        """
        self.__symbol_table_dict = {}
        for key in self.__counters_dict:
            self.__counters_dict[key] = 0

    def define(self, name, type, kind):
        """
        enters a new var to the symbol table
        """
        kind = "local" if kind == "var" else kind
        index = self.varCount(kind)
        self.__symbol_table_dict[name] = [type, kind, index]
        self.__counters_dict[kind] += 1

    def varCount(self, kind):
        """
        returns how many vars are from the given kind
        """
        return self.__counters_dict[kind]

    def type_of(self, name):
        """
        returns the type of a given var
        """
        if name in self.__symbol_table_dict.keys():
            return self.__symbol_table_dict[name][0]

        return None

    def kind_of(self, name):
        """
        returns the kind of a given var
        """
        if name in self.__symbol_table_dict.keys():
            return self.__symbol_table_dict[name][1]

        return None

    def index_of(self, name):
        """
        returns the index of a given var
        """
        if name in self.__symbol_table_dict.keys():
            return self.__symbol_table_dict[name][2]

        return None

    def get_size(self):
        """
        returns the size of the table
        """
        return len(self.__symbol_table_dict)

    def is_in(self, var):
        """
        returns true if a given var is in the table
        """
        return var in self.__symbol_table_dict
