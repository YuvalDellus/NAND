import Tokenizer
import sys
tokenizer = Tokenizer.Tokenizer(sys.argv[1])

# import  SymbolTable
#
# temp = SymbolTable.SymbolTable()
#
# temp.define("name","type","Static")
# temp.define("name2","type","Static")
# print(temp.index_of("name2"))
# temp.start_subroutine()
# print(temp.kind_of("name2"))
