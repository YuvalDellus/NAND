class VMWriter:

    def __init__(self, output_file):
        self.output_file = open(output_file, 'w')
        self.output = ""

    def write_push(self, segment, index):
        """
        writes push command in the vm language
        :param segment: the segment of the var
        :param index: the index
        """
        if segment == "var": segment = "local"
        if segment == "field": segment = "this"
        self.output_file.write("push %s %s\n" % (segment, index))
        self.output += "push %s %s\n" % (segment, index)

    def write_pop(self, segment, index):
        """
        writes pop command in the vm language
        :param segment: the segment of the var
        :param index: the index
        """
        if segment == "var": segment = "local"
        if segment == "field": segment = "this"
        self.output_file.write("pop %s %d\n" % (segment, index))
        self.output += "pop %s %d\n" % (segment, index)

    def write_arithmetic(self, command):
        """
        writes arithmetic command in vm language
        :param command: the command
        """
        commands_dic = {
            "+": "add", "-": "sub", "-unary": "neg",
            "=": "eq", ">": "gt", "<": "lt",
            "&": "and", "|": "or", "~unary": "not"
        }

        complex_command_dic = {
            "*": "Math.multiply",
            "/": "Math.divide"
        }
        if (command in commands_dic):
            self.output_file.write(commands_dic[command])
            self.output_file.write("\n")
            self.output += commands_dic[command]
        else:
            self.write_call(complex_command_dic[command], 2)

    def write_label(self, label):
        """
        writes label in the vm language
        :param label: the label
        """
        self.output_file.write("label %s\n" % label)
        self.output += "label %s\n" % (label)

    def write_goto(self, label):
        """
        writes goto label in the vm language
        :param label: the label
        """
        self.output_file.write("goto %s\n" % label)
        self.output += "goto %s\n" % (label)

    def write_if(self, label):
        """
        writes if in the vm language
        :param label: the label
        """
        self.output_file.write("if-goto %s\n" % label)
        self.output += "if-goto %s\n" % (label)

    def write_call(self, name, nargs):
        """
        writes call statement in the vm language
        :param name: the name of the function
        :param nargs: the number of args it's take
        """
        self.output_file.write("call %s %d\n" % (name, nargs))
        self.output += "call %s %d\n" % (name, nargs)

    def write_function(self, name, nLocals):
        """
        writes function statement in the vm language
        :param name: the name of the function
        :param nargs: the number of args it's take
        """
        self.output_file.write("function %s %d\n" % (name, nLocals))
        self.output += "function %s %d\n" % (name, nLocals)

    def write_return(self):
        """
        writes return statement
        :return:
        """
        self.output_file.write("return\n")
        self.output += "return\n"

    def write_string(self, string):
        """
        writes strings to the vm, letter by letter
        :param string: the string needed to be pushed
        """
        i = 0
        string_len = 0

        while i < len(string):  # checking for string len without special chars
            letter = string[i]
            if letter == "\\":
                i += 2
                if i + 1 < len(string):
                    if string[i + 1] == "t" or string[i + 1] == "*":
                        string_len += 2
            i += 1
            string_len += 1

        i = 0

        self.write_push("constant", string_len)
        self.write_call("String.new", 1)

        while i < len(string):

            letter = string[i]

            if letter == "\\":  # in case of \
                ascii_rep = 9  # in case of \t
                if string[i + 1] == "*": ascii_rep = 42
                self.write_push("constant", ascii_rep)
                self.write_call("String.appendChar", 2)
                i += 2
                continue

            self.write_push("constant", ord(letter))
            self.write_call("String.appendChar", 2)
            i += 1

    def write_keyword(self, keyword):
        """
        used in case of unary operator
        """
        self.write_push("constant", 0)
        if keyword == "true": self.write_arithmetic("~unary")

    def write_alloc(self, args_num):
        """
        writes alloc
        :param args_num: the number of cells in the memory
        """
        self.write_push("constant", args_num)
        self.write_call("Memory.alloc", 1)
        self.write_pop("pointer", 0)

    def close(self):
        """
        closes the file
        """
        self.output_file.close()
