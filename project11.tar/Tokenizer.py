import glob, os, sys, re
import CompilationEngine


class Tokenizer:
    '''
    class that separates the jack file to tokens in XML format
    '''

    def __init__(self, path):
        '''
        constructor, intializes the fields and calls the main action function
        :param path:
        '''
        self._path = path
        self.__files = self.open_files(path)
        self._comment_flag = False
        self.readFile()

    def open_files(self, path):
        '''
        checks if directory is a single file or a directory to multiple files
        :return:an array of files to work on
        '''

        if os.path.isdir(path):
            files = []
            for filename in glob.glob(os.path.join(path, "*.jack")):
                files.append(open(filename, "r"))
            return files  # + "/" + sys.argv[1].split("/")[-1] + ".asm"
        else:
            return [open(path, "r")]  # , sys.argv[1].replace(".vm", ".asm")

    def readFile(self):
        '''
        for each file in the directory, translates it to tokens and then to an
        xml representation by the compilation engiene
        :return:
        '''
        func_list = [self.keyword_xml_creator, self.symbol_xml_creator, self.integer_xml_creator,
                     self.string_xml_creator, self.identifier_xml_creator]
        for i, file in enumerate(self.__files):
            output = "<tokens>\n"

            line = file.readline()
            while line:
                line = self.clean_line(line)
                if (not line):
                    line = file.readline()
                    continue

                for token in line:
                    for func in func_list:
                        xml_line = func(token)
                        if (xml_line):
                            output += xml_line
                            break
                line = file.readline()

            output += "</tokens>\n"
            file.close()
            CompilationEngine.CompilationEngine(output, file.name.replace(".jack", ".vm"))

    def clean_line(self, line):
        '''
        receives a line and returns a line without redundant spaces
        or none if the line is a comment
        :param line:
        :return: an array of the line split by " " if line is a
        '''

        line = line.replace("\n", "")
        line = line.replace("\t", "")
        p = re.compile("[^\"]*(\*\/)(.*)")
        m = p.match(line)

        if (m):
            line = line[line.find(m.group(1)) + 2:]

        p = re.compile("[^\"]*(\/\/|\/\*).*|\s*(\*).*")
        m = p.match(line)
        if (m):
            first_found_group = m.group(1) if m.group(1) else m.group(2)
            line = line[:line.find(first_found_group)]

        return self.fix_spliting(line)

    def fix_spliting(self, line):
        '''
        splits the line as needed for tokens
        :param line:
        :return: line in tokens as an array
        '''
        const_string = ""
        p = re.compile(".*(\"(.*?)\").*")
        m = p.match(line)
        if m:
            const_string = m.group(1)
            line = line.replace(m.group(1), "\"")

        temp_tok = re.split('(\W)', line)
        temp = [x for x in temp_tok if x and x != " "]
        if (const_string):
            i = temp.index("\"")
            temp[i] = const_string

        return temp

    ##################################################
    # following functions create the matching xml line
    # for each token
    ##################################################

    def keyword_xml_creator(self, token):
        '''
        function for recognition of keywords
        :param token:
        :return: a matching line, if the given token as an keyword
        '''
        possible_keywords = ["class", "constructor", "function", "method", "field", "static", "var", "int", "char",
                             "boolean", "void", "true", "false", "null", "this", "let", "do", "if", "else", "while",
                             "return"]
        if (token in possible_keywords):
            return "<keyword> %s </keyword>\n" % token

    def symbol_xml_creator(self, token):
        '''
           function for recognition of symbols
           :param token:
           :return: a matching line, if the given token as a symbol
        '''
        possible_symbols = {"{": "{", "}": "}",
                            "(": "(", ")": ")",
                            "[": "[", "]": "]",
                            ".": ".", ",": ",", ";": ";",
                            "+": "+", "-": "-", "*": "*",
                            "/": "/", "&": "&amp;", "|": "|",
                            "<": "&lt;", ">": "&gt;", "=": "=",
                            "~": "~"
                            }
        if (token in possible_symbols.keys()):
            return "<symbol> %s </symbol>\n" % possible_symbols[token]

    def integer_xml_creator(self, token):
        '''
           function for recognition of integer consts
           :param token:
           :return: a matching line, if the given token as a number
        '''
        if re.match("^\d+?\.\d+?$", token) is not None or token.isdigit():
            return "<integerConstant> %s </integerConstant>\n" % token

    def string_xml_creator(self, token):
        '''
           function for recognition of string consts
           :param token:
           :return: a matching line, if the given token as an string
        '''
        if (token[0] == "\""):
            return "<stringConstant> %s </stringConstant>\n" % token.replace("\"", "")

    def identifier_xml_creator(self, token):
        '''
           function for recognition of identifier
           :param token:
           :return: a matching line, if the given token as a identifier
        '''
        return "<identifier> %s </identifier>\n" % token
