PUSH = "@SP\nA=M\nM=D\n@SP\nM=M+1\n"  # entering the number for position and updates SP
PUSH_PREFIX1 = "@%s\nD=A\n@%s\nA=M+D\nD=M\n"  # for regular numbers
PUSH_PREFIX2 = "@%s\nD=A\n"  # for static
PUSH_PREFIX3 = "@%s\nD=M\n"  # for pointers
PUSH_PREFIX4 = "@%s\nD=A\nD=D-1\nD=!D\n"  # for negative numbers (only in const)
PUSH_PREFIX5 = "@%s\nD=A\n@%s\nA=A+D\nD=M\n"  # for temp numbers

POP = "@%s\nD=A\n@%s\nD=M+D\n@14\nM=D\n@13\nD=M\n@14\nA=M\nM=D\n"
POP_FOR_TEMP = "@%s\nD=A\n@%s\nD=A+D\n@14\nM=D\n@13\nD=M\n@14\nA=M\nM=D\n"
POP_PREFIX = "@SP\nAM=M-1\nD=M\n@13\nM=D\n"
POP_POINTER = "@%s\nM=D\n"
POP_FOR_STATIC = "@%s\nM=D\n"

OVER_FLOW_HANDLE = "@SP\nA=M-1\nA=A-1\nD=!M\nA=A+1\nD=D&M\n@14\nM=D\n@SP\nA=M-1" \
                   "\nD=!M\nA=A-1\nD=D&M\n@14\nD=M|D\n@NOOVERFLOW%d\nD;JGE\n@SP" \
                   "\nM=M-1\nA=M-1\nD=M\nM=%d\n@POSSITIVE%d\nD;JGE\n@SP\nA=M-1\nM=%d\n(POSSITIVE%d)\n" \
                   "@FIN%d\nD;JMP\n(NOOVERFLOW%d)\n"
SET_ANSWER_TO_TRUE = "D=M\n@SP\nA=M-1\nD=M-D\nM=-1\n"
FINAL_COMPARISON = "@SKIP%d\nD;%s\n@SP\nA=M-1\nD=D-M\nM=0\n(SKIP%d)\n(FIN%d)\n"
GET_TOP = "@SP\nM=M-1\nA=M\n"

RECONSTRUCT_ADDRESSES = "@frame.%s\nM=M-1\nA=M\nD=M\n@%s\nM=D\n"
SAVE_ADDRESSES = "@%s\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
addresses = ["THAT", "THIS", "ARG", "LCL"]

valid_names = {"local": "LCL", "argument": "ARG", "this": "THIS",
               "that": "THAT"}


def push_command(address, arg, file_name=None):
    '''
    :param address: type of the needed segment in the memory (local, pointers, etc..)
    :param arg: number in the segment
    :param file_name:
    :return: code for executing the push command from the requested segment in
     the memory
    '''
    if address in valid_names.keys():
        return PUSH_PREFIX1 % (arg, valid_names.get(address)) + PUSH

    if address == "temp":
        address = "5"
        return PUSH_PREFIX5 % (arg, address) + PUSH

    if address == "constant":
        if "-" in arg:
            arg = arg.replace("-", "")
            address = arg
            return PUSH_PREFIX4 % address + PUSH
        address = arg

    if address == "static":
        address = "%s.%s" % (file_name, arg)
        return PUSH_PREFIX3 % address + PUSH

    if address == "pointer":
        if arg == "0":
            address = "THIS"
            return PUSH_PREFIX3 % address + PUSH
        else:
            address = "THAT"
            return PUSH_PREFIX3 % address + PUSH

    return PUSH_PREFIX2 % address + PUSH


def pop_command(address, arg, file_name=None):
    '''
    :param address: type of the needed segment in the memory (local, pointers, etc..)
    :param arg: number in the segment
    :return:assembly code for executing the pop command to the requested segment in
     the memory
    '''
    if address in valid_names.keys():
        return POP_PREFIX + POP % (arg, valid_names.get(address))

    if address == "temp":
        address = "5"
        return POP_PREFIX + POP_FOR_TEMP % (arg, address)

    if address == "pointer":
        if arg == "0":
            address = "THIS"
        else:
            address = "THAT"
        return POP_PREFIX + POP_POINTER % address

    if address == "static":
        address = "%s.%s" % (file_name, arg)
        return POP_PREFIX + POP_FOR_STATIC % (address)


def add_command(sign="+"):
    '''
    :param sign: whether to add or subtract
    :return:assembly code for executing the addition command of last two
    components of the stack
    '''
    return GET_TOP + "D=M\n@SP\nA=M-1\nM=M%sD\n" % (sign)


def sub_command():
    '''
    :return:code for executing the subtraction command of last two components
    of the stack
    '''
    return add_command("-")


def neg_command():
    '''
    :return: code for executing the negation command of last component
    in the stack
    '''
    return "@0\nD=A\n@SP\nA=M-1\nM=D-M\n"


def compare_command(c_type, line_num):
    '''
    :param c_type: requested comparision
    :param line_num: number of command
    :return: code for executing the commemoration(gt,lt,eq) command of
    last two components of the stack
    '''
    result = 0
    n_result = 0
    if (c_type == "JGT"):
        result = -1
        n_result = 0
    elif (c_type == "JLT"):
        result = 0
        n_result = -1

    out = OVER_FLOW_HANDLE % (
        line_num, result, line_num, n_result, line_num, line_num, line_num)
    out += GET_TOP + SET_ANSWER_TO_TRUE + FINAL_COMPARISON % (
        line_num, c_type, line_num, line_num)
    return out


def not_command():
    '''
    :return:code for executing the bit-wise negation command of last component
     in the stack
    '''
    return "@SP\nA=M-1\nM=!M\n"


def or_and_commands(operator):
    '''
    :param operator:
    :return:code for executing the bit-wise and/or command of last component
     in the stack
    '''
    return GET_TOP + "D=M\n@SP\nA=M-1\nM=D%sM\n" % operator


def write_label(label):
    '''
    write labels for go-to
    :param label:
    :return: assembly code for creating a label
    '''
    return "(%s)\n" % (label)


def write_goto(label):
    '''
    create go to
    :param label:
    :return: assembly code for a go-to command
    '''
    return "@%s\n0;JMP\n" % label


def write_ifgoto(label):
    '''
    :param label:
    :return: assembly code for a if go-to command
    '''

    return "@SP\nM=M-1\nA=M\nD=M\n@%s\nD;JNE\n" % label


def write_function(name, args_nums):
    '''
    handles function def
    :param name: of the function
    :param args_nums: numbers of locals used in the function
    :return: matching assembly code for starting a function
    '''
    return write_label(name) + "\n@SP\nA=M\n" + "M=0\nA=A+1\n" * int(
        args_nums) + "D=A\n@SP\nM=D\n"


def write_call_function(name, args_nums, line_num, file_name):
    '''
    :param name: function names
    :param args_nums: variables transferred to the function
    :param line_num:
    :param file_name:
    :return:  matching assembly code for calling a function
    '''
    output = ""
    for address in addresses[::-1]:
        output += SAVE_ADDRESSES % (address)

    return "@%s.%s$ret.%s\nD=A\n@SP\nM=M+1\nA=M-1\nM=D\n" % (
    file_name, name, line_num) + output + \
           "@SP\nD=M\n@5\nD=D-A\n@%s\nD=D-A\n@ARG\nM=D\n" % (args_nums) + \
           "@SP\nD=M\n@LCL\nM=D\n" + "@%s\n0;JMP\n" % (name) + \
           "(%s.%s$ret.%s)\n" % (file_name, name, line_num)

def write_return(line_num):
    '''
    :param line_num:
    :return: matching assembly code for a return
    '''
    output = ""
    for address in addresses:
        output += RECONSTRUCT_ADDRESSES % (line_num, address)

    return "@LCL\nD=M\n@frame.%s\nM=D\n" % line_num + \
           "@5\nA=D-A\nD=M\n@retaddress.%s\nM=D\n" % line_num + \
           "@SP\nAM=M-1\nD=M\n@ARG\nA=M\nM=D\n" + \
           "@ARG\nD=M+1\n@SP\nM=D\n" + output + "@retaddress.%s\nA=M\n0;JMP\n" % line_num


def translator(command_type, adress, argument, file_name, line_num):
    '''
    :param command_type:
    :param adress:
    :param argument:
    :param file_name:
    :param line_num:
    :return: recives parameters of command line and sends it to the suitable
    function
    '''
    if (command_type == "push"):
        return push_command(adress, argument, file_name)
    if (command_type == "pop"):
        return pop_command(adress, argument, file_name)
    if (command_type == "add"):
        return add_command()
    if (command_type == "sub"):
        return sub_command()
    if (command_type == "neg"):
        return neg_command()
    if (command_type == "eq"):
        return compare_command("JEQ", line_num)
    if (command_type == "gt"):
        return compare_command("JGT", line_num)
    if (command_type == "lt"):
        return compare_command("JLT", line_num)
    if (command_type == "not"):
        return not_command()
    if (command_type == "or"):
        return or_and_commands("|")
    if (command_type == "and"):
        return or_and_commands("&")
    if (command_type == "label"):
        return write_label(adress)
    if (command_type == "goto"):
        return write_goto(adress)
    if (command_type == "if-goto"):
        return write_ifgoto(adress)
    if (command_type == "function"):
        return write_function(adress, argument)
    if (command_type == "call"):
        return write_call_function(adress, argument, line_num, file_name)
    if (command_type == "return"):
        return write_return(line_num)
    return None
