import glob, os, sys
import Parser
import CodeWriter


def receive_input():
    '''
    checks if directory is a single file or a directory to multiple files
    :return:an array of files to work on
    '''
    # output = sys.argv[1].split("\\")[-1]
    if os.path.isdir(sys.argv[1]):
        files = []
        for filename in glob.glob(os.path.join(sys.argv[1], "*.vm")):
            files.append(open(filename, "r"))
        return files, sys.argv[1] + "/" + sys.argv[1].split("/")[-1] + ".asm"
    else:

        return [open(sys.argv[1], "r")], sys.argv[1].replace(".vm", ".asm")


def main():
    files_list, output_file_path = receive_input()
    output = "@256\nD=A\n@SP\nM=D\n"
    line_num = 0
    for file in files_list:
        line = "call Sys.init 0"
        path = os.path.basename(file.name)

        file_name = os.path.splitext(path)[0]

        while line:

            command_txt, command_type, memory_address, argument = Parser.read_single_line(
                line)
            asm_lines = CodeWriter.translator(command_type, memory_address,
                                              argument, file_name, line_num)
            if (command_txt):
                output += "//" + command_txt + "\n"
                line_num += 1
            if (asm_lines):
                output += asm_lines
            line = file.readline()
        file.close()

    asm_code = open(output_file_path, "w")
    asm_code.write(output)
    asm_code.close()


main()
