import CCommands

AVALIBLE_SPOT = " "

symbol_table = {AVALIBLE_SPOT: "16"}
special_symbol_table = {}


def update_avalible(adress):
    ''' the symbol tables saves the next avalible register number,
    this function updates it
    '''
    if symbol_table[AVALIBLE_SPOT] == adress:
        k = int(symbol_table[AVALIBLE_SPOT])
        while (str(k) in symbol_table.values()):
            k += 1
        symbol_table[AVALIBLE_SPOT] = str(k)


def delete_spaces(line):
    '''
    :param line:
    :return: line without spaces
    '''
    i = 0
    while (line[i] != " "):
        line = line[i:]
        i += 1


# delete all blank spaces in start and end of line, comments and empty line
def trim(line):
    currLine = ""
    for letter in line:
        if letter != '/' and letter != ' ' and letter != '\n' and letter != '\t':
            currLine += letter
        if letter == '/':
            break
            # print(line)
    return currLine


def first_read(lines_array):
    '''
    does the first read, saves all the lines in form of "(###)" to the symbol
    tables
    :param lines_array:
    :return: fixed array without commands or spaces and empty lines
    '''
    i = 0
    fix_lines_array = []
    for command in lines_array:
        command = trim(command)
        if command != "":
            fix_lines_array.append(command)
            if command[0] == "(" and command[-1] == ")":
                symbol_table[command[1:-1]] = str(i)
                update_avalible(i)
            else:
                i += 1

    return fix_lines_array


def second_read(asm_code):
    '''
    reads for the second time the fixed code, checks if it is an A or C command
    and return output that represents all the commands in binary
    :param asm_code:
    :return:
    '''
    special_sybmols_create()
    output = []
    for command in asm_code:
        if command[0] == "@":
            output.append(A_command(command[1:]))
        else:
            if (command[0] == "("):
                continue
            output.append(C_command(command))
    return output


def A_command(command):
    '''
    treats cases of A commands
    :param command:
    :return: binary output for the received command
    '''
    if (command not in symbol_table.keys()):  # if a new varible
        i = determine_address(command)
        symbol_table[command] = str(int(i))

    output_bin = str(bin(int(symbol_table[command])))[2:]
    return "0" * (16 - len(output_bin)) + output_bin


def determine_address(name):
    '''
    if we need to fill a new register, this function decides which one
    :param name:
    :return:
    '''
    if (name in special_symbol_table.keys()):
        return special_symbol_table[name]
    if name.isdigit():
        # if name not in symbol_table.values():
        return name
    i = symbol_table[AVALIBLE_SPOT]
    update_avalible(symbol_table[AVALIBLE_SPOT])
    return i


def C_command(command):
    '''
    treats C commands by sanding it to another function
    :param command:
    :return: binary output that represents the command
    '''
    return CCommands.CommandParser(command)


def special_sybmols_create():
    '''
    creates table that contains special register as "KBD" or "SCREEN"
    :return:
    '''
    for i in range(16):
        special_symbol_table["R" + str(i)] = i
    special_symbol_table["SCREEN"] = "16384"
    special_symbol_table["KBD"] = "24576"
    special_symbol_table["SP"] = "0"
    special_symbol_table["LCL"] = "1"
    special_symbol_table["ARG"] = "2"
    special_symbol_table["THIS"] = "3"
    special_symbol_table["THAT"] = "4"
