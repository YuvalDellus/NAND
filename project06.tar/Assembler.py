import Parser
import sys
import os
import glob


def read_into_array(file):
    '''
    :param file: assambler code
    :return: an array with all the lines in the file
    '''
    for line in file:
        lines = (line.rstrip() for line in file)  # All lines including the blank ones
        lines = (line for line in lines if line)  # Non-blank lines
        return lines


def receive_input():
    '''
    checks if directory is a single file or a directory to multiple files
    :return:an array of files to work on
    '''
    if os.path.isdir(sys.argv[1]):
        files = []
        for filename in glob.glob(os.path.join(sys.argv[1], "*.asm")):
            files.append(open(filename, "r"))
        return files
    else:
        return [open(sys.argv[1], "r")]


def main():
    '''
    recives input runs the compiler on the asm code and creates a .hack file in
    the directory of the original
    :return:
    '''
    files = receive_input()

    for file in files:
        lines = read_into_array(file)
        lines2 = Parser.first_read(lines)
        new_file_name = file.name.replace(".asm", ".hack")
        hack_code = open(new_file_name, "w")
        hack_code.write("\n".join(Parser.second_read(lines2)))
        file.close()
        hack_code.close()


main()
