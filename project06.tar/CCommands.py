def compParser(string):
    """
    This function treats the comp part of the command and translate it to binary
    :param string: The comp part in assembly language.
    :return: the comp part in binary.
    """
    comp_dict = {
        "0": "101010", "1": "111111", "-1": "111010",
        "D": "001100", "A": "110000", "!D": "001101",
        "!A": "110001", "-D": "001111", "-A": "110011",
        "D+1": "011111", "A+1": "110111", "D-1": "001110",
        "A-1": "110010", "D+A": "000010", "D-A": "010011",
        "A-D": "000111", "D&A": "000000", "D|A": "010101",
        "M": "110000", "!M": "110001", "-M": "110011",
        "M+1": "110111", "M-1": "110010", "D+M": "000010",
        "D-M": "010011", "M-D": "000111", "D&M": "000000",
        "D|M": "010101",
        "D<<": "110000", "A<<": "100000", "M<<": "100000",
        "D>>": "010000", "A>>": "000000", "M>>": "000000",
    }
    shift_list = ["D<<", "A<<", "M<<", "D>>", "A>>", "M>>"]

    m_list = ["M", "!M", "-M", "M+1", "M-1", "D+M", "D-M", "M-D", "D&M", "D|M",
              "M>>", "M<<"]

    a_digit = "0"
    shift_digit = "11"

    if string in m_list:
        a_digit = "1"

    if string in shift_list:
        shift_digit = "01"

    full_digit = shift_digit + a_digit + comp_dict.get(string)
    return full_digit


def destParser(string):
    """
    This function treats the dest part of the command and translate it to binary
    :param string: The dest part in assembly language.
    :return: the dest part in binary.
    """
    dest_dict = {
        "M": "001", "D": "010", "MD": "011",
        "A": "100", "AM": "101", "AD": "110",
        "AMD": "111", "": "000"
    }

    return dest_dict.get(string)


def jumpParser(string):
    """
    This function treats the jump part of the command and translate it to binary
    :param string: The jump part in assembly language.
    :return: the jump part in binary.
    """
    jump_dict = {
        "JGT": "001", "JEQ": "010", "JGE": "011",
        "JLT": "100", "JNE": "101", "JLE": "110",
        "JMP": "111", "": "000"
    }

    return jump_dict.get(string)


def CommandParser(string):
    """
    This function takes the C-command and breaks it to its different parts, send it to the other sub-function and return
     the full binary representation of the command.
    :param string: The C-command
    :return: the C-command in binary.
    """
    parts = ["", "", ""]
    if "=" in string:
        parts[0] = string.split("=")[0]
        if ";" not in string:
            parts[1] = string.split("=")[1]
    if ";" in string:
        parts[2] = string.split(";")[1]
        if "=" not in string:
            parts[1] = string.split(";")[0]
    if "=" in string and ";" in string:
        parts[1] = string.split("=")[1].split(";")[0]

    return (
        "1" + compParser(parts[1]) + destParser(parts[0]) + jumpParser(
            parts[2]))
